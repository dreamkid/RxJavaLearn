package com.example.rxjavalearn.activity

import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import com.example.rxjavalearn.R
import kotlinx.android.synthetic.main.activity_introduction.*

class IntroductionActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_introduction)

        this.actionBar?.setIcon(android.R.drawable.ic_menu_close_clear_cancel)
        actionBar?.setTitle(resources.getString(R.string.abc_action_bar_home_description))
        webview.loadUrl("file:///android_asset/introduction.html")
    }
}
